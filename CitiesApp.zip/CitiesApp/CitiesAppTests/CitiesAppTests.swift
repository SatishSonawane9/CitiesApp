//
//  CitiesAppTests.swift
//  CitiesAppTests
//
//  Created by Admin on 24/01/25.
//

import XCTest
@testable import CitiesApp

final class CitiesAppTests: XCTestCase {
    var webApiHandler: WebApiHandler!
    
    override func setUp() {
        super.setUp()
        webApiHandler = WebApiHandler()
    }
    
    override func tearDown() {
        super.tearDown()
    }

    func testFetchCityRecords() async {
        do {
            let cityList = try await webApiHandler.fetchCityRecords()
            XCTAssertFalse(cityList.isEmpty, "City list should not be empty.")
            if let firstCity = cityList.first {
                XCTAssertEqual(firstCity.city, "Sydney", "First city should be Sydney.")
            }
        } catch {
            XCTFail("Fetching city records failed with error: \(error.localizedDescription)")
        }
    }
}
