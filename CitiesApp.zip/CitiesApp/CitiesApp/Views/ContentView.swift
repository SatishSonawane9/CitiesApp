//
//  ContentView.swift
//  CitiesApp
//
//  Created by Admin on 24/01/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = CityViewModel()
    @State private var expandedSections: Set<String> = []
    
    var body: some View {
        NavigationView {
            VStack {
                
                Button(action: {
                    viewModel.reverseList()
                }) {
                    Text(viewModel.isReversed ? "Show in Original Order" : "Reverse List")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding()
                
                List {
                    ForEach(viewModel.groupedCities, id: \.state) { group in
                        Section(header: HStack {
                            // +, - handle
                            Text(group.state)
                                .font(.headline)
                                .padding(.leading)
                            
                            Spacer()
                            
                            Image(systemName: expandedSections.contains(group.state) ? "minus.circle" : "plus.circle")
                                .foregroundColor(.blue)
                                .onTapGesture {
                                    toggleSection(group.state)
                                }
                        }) {
                            if expandedSections.contains(group.state) {
                                ForEach(group.cities) { city in
                                    VStack(alignment: .leading) {
                                        Text(city.city)
                                            .font(.subheadline)
                                        Text("City: \(city.city)")
                                            .font(.footnote)
                                        Text("Lat: \(city.lat)")
                                            .font(.footnote)
                                        Text("Lng: \(city.lng)")
                                            .font(.footnote)
                                        Text("Country: \(city.country)")
                                            .font(.footnote)
                                        Text("ISO2: \(city.iso2)")
                                            .font(.footnote)
                                        Text("Admin Name: \(city.adminName)")
                                            .font(.footnote)
                                        Text("Capital: \(city.capital)")
                                            .font(.footnote)
                                        Text("Population: \(city.population)")
                                            .font(.footnote)
                                        Text("Population Proper: \(city.populationProper)")
                                            .font(.footnote)
                                    }
                                    .padding(.vertical, 5)
                                }
                            }
                        }
                    }
                }
                .navigationTitle("Cities by State - Australia")
                .navigationBarTitleDisplayMode(.inline)
                .onAppear {
                    viewModel.fetchCities()
                }
            }
            .navigationViewStyle(StackNavigationViewStyle())
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(.dark)
    }
        
    private func toggleSection(_ state: String) {
        if expandedSections.contains(state) {
            expandedSections.remove(state)
        } else {
            expandedSections.insert(state)
        }
    }
}

#Preview {
    ContentView()
}
