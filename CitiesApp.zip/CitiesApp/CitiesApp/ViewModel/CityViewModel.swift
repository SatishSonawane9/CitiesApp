//
//  CityViewModel.swift
//  CitiesApp
//
//  Created by Admin on 24/01/25.
//

import Foundation
import Combine

class CityViewModel: ObservableObject {
    @Published var cities: [CityList] = []
    @Published var groupedCities: [GroupedCities] = []
    @Published var isReversed: Bool = false
    private let apiHandler = WebApiHandler()
    
    func fetchCities() {
        Task {
            do {
                let cityList = try await apiHandler.fetchCityRecords()
                DispatchQueue.main.async {
                    self.cities = cityList
                    self.groupCities()
                }
                
            } catch {
                print("Failed to fetch cities: \(error)")
            }
        }
    }
    
    func groupCities() {
        let grouped = Dictionary(grouping: cities, by: { $0.adminName })
        DispatchQueue.main.async {
            self.groupedCities = grouped.map { GroupedCities(state: $0.key, cities: $0.value) }
            self.groupedCities.sort { $0.state < $1.state }
            if self.isReversed {
                self.groupedCities.reverse()
            }
        }
    }

    func reverseList() {
        isReversed.toggle()
        groupCities()
    }
}
