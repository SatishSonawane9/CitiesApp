//
//  WebApiHandler.swift
//  CitiesApp
//
//  Created by Admin on 24/01/25.
//

import Foundation

class WebApiHandler {
    
    func fetchCityRecords() async throws -> [CityList]  {
        guard let url = Bundle.main.url(forResource: "au_cities", withExtension: "json") else {
            throw NSError(domain: "InvalidURL", code: 0, userInfo: nil)
        }
        
        do {
            let data = try Data(contentsOf: url)
            
            // Step 3: Decode the JSON data into the City model
            let decoder = JSONDecoder()
            let city = try decoder.decode([CityList].self, from: data)
            
            return city
        } catch {
            print("Error loading or decoding the JSON file: \(error)")
            return []
        }
    }
}
